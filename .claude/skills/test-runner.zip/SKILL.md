---
name: test-runner
description: Run unit test files using npm. This skill should be used when users request to execute specific test files or test cases, such as "run these test cases" or "help me run xx, xx tests."
---

# Test Runner Skill

## Purpose

Execute unit test files using the project's npm test command. Parse user-specified test file paths and run them individually or as a group.

## When to Use

Trigger this skill when users:
- Ask to run specific test files: "运行 xxx.test.ts, yyy.test.ts"
- Request test execution: "帮我运行这几个测试用例"
- Mention running tests with specific file patterns

## How to Use

1. **Parse User Input**
   - Extract test file paths from user request
   - Handle comma-separated lists or multiple file references
   - Support both relative and absolute paths

2. **Verify Test Files Exist**
   - Check if specified test files exist in the project
   - Look in common test directories: `tests/`, `test/`, `__tests__/`, `src/`
   - Alert user if any files are not found

3. **Run Tests**
   - Use the project's test runner (typically: `npm test <file>`)
   - If running multiple files, execute each file separately
   - Display results clearly for each test file

4. **Report Results**
   - Show pass/fail status for each test
   - Highlight any failures or errors
   - Provide summary of total tests run

## Example Commands

```bash
# Run single test file
npm test tests/unit/example.test.ts

# Run multiple test files
npm test tests/unit/example.test.ts tests/integration/api.test.ts

# Run tests with pattern (if project supports it)
npm test -- tests/unit/*.test.ts
```

## Notes

- This skill assumes the project uses npm for test management
- Test file extensions may vary: `.test.ts`, `.test.js`, `.spec.ts`, `.spec.js`
- Adjust commands based on project's test configuration (vitest, jest, etc.)
